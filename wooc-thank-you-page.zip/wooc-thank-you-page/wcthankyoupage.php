<?php
/**
 Plugin Name: WooCommerce Thank you Page
 Plugin URI: https://arcosmultimedia.com
 Description: You can use this plugin to add a thank you page after customer placing an order, create a new Page using any Wordpress Page Builder. to start using the thank you page plugin go to WooCommerce > Settings > Thank You Page > and select the Page you created.
 Version: 1.0
 Author: Arcos Multimedia Group
 Author URI: https://arcosmultimedia.com
 License: GPL2

 */

 include 'wcproductthankyoupage.php';
 
add_filter( 'woocommerce_settings_tabs_array', 'cwpai_add_new_settings_tab', 50 );
function cwpai_add_new_settings_tab( $settings_tabs ) {
    $settings_tabs['thank_you_page'] = __( 'Thank You Page', 'woocommerce' );
    return $settings_tabs;
}

// Add Settings fields
add_action( 'woocommerce_settings_tabs_thank_you_page', 'cwpai_woo_add_thank_you_page_setting_fields' );
function cwpai_woo_add_thank_you_page_setting_fields() {
    woocommerce_admin_fields( cwpai_get_thank_you_page_settings_fields() );
}

function cwpai_get_thank_you_page_settings_fields() {
    $fields = array(
        'section_title' => array(
            'name' => __( 'Thank You Page', 'woocommerce' ),
            'type' => 'title',
            'desc' => '',
            'id' => 'wc_settings_thank_you_page_section_title'
        ),
        'page_selection' => array(
            'name' => __( 'Thank You Page Page', 'woocommerce' ),
            'type' => 'select',
            'options' => cwpai_get_all_pages(),
            'id' => 'wc_settings_thank_you_page_id'
        ),
        'section_end' => array(
            'type' => 'sectionend',
            'id' => 'wc_settings_thank_you_page_section_end'
        ),
    );

    return apply_filters( 'wc_settings_tab_thank_you_page_fields', $fields );
}

function cwpai_get_all_pages() {
    $pages = get_pages();
    $options = array();
    $options[''] = 'Disabled';
    foreach( $pages as $page ) {
        $options[$page->ID] = $page->post_title;
    }

    return $options;
}

// Handle Page Selection
add_action( 'woocommerce_update_options_thank_you_page', 'cwpai_woo_update_thank_you_page_setting_fields' );
function cwpai_woo_update_thank_you_page_setting_fields() {
    $settings = cwpai_get_thank_you_page_settings_fields();
    woocommerce_update_options( $settings );
}

// Redirect to Thank You Page
add_action( 'woocommerce_thankyou', 'cwpai_redirect_to_thank_you_page' );
function cwpai_redirect_to_thank_you_page( $order_id ) {
    $thank_you_page_id = get_option( 'wc_settings_thank_you_page_id', '' );
    if ( $thank_you_page_id && $order_id ) {
        $order = wc_get_order( $order_id );
        if( $order && ( 'processing' === $order->get_status() || 'completed' === $order->get_status() ) ) {
            $url = get_permalink( $thank_you_page_id );
            wp_redirect( $url );
            exit;
        }
    }
}

?>