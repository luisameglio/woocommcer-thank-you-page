<?php
// Add custom field to product edit page
add_action( 'woocommerce_product_options_general_product_data', 'cwpai_woo_add_custom_field_to_product_edit_page' );
function cwpai_woo_add_custom_field_to_product_edit_page() {
    global $woocommerce, $post;
    echo '<div class="options_group">';
    woocommerce_wp_select( 
        array( 
            'id'            => '_thank_you_page', 
            'label'         => __( 'Thank You Page', 'woocommerce' ), 
            'options'       => cwpai_woo_get_dropdown_options(),
            'desc_tip'      => 'true',
            'description'   => __( 'Select thank you page for this product', 'woocommerce' ) 
        )
    );
    echo '</div>';
}

// Save custom field to product
add_action( 'woocommerce_process_product_meta', 'cwpai_woo_save_custom_field_to_product' );
function cwpai_woo_save_custom_field_to_product( $post_id ) {
    $product = wc_get_product( $post_id );
    $selected_page = isset( $_POST['_thank_you_page'] ) ? sanitize_text_field( $_POST['_thank_you_page'] ) : '';
    $product->update_meta_data( '_thank_you_page', $selected_page );
    $product->save();
}

// Get all pages for dropdown
function cwpai_woo_get_dropdown_options() {
    $pages = get_pages();
    $options = array();
    $options[''] = 'Disabled';
    foreach( $pages as $page ) {
        $options[$page->ID] = $page->post_title;
    }

    return $options;
}

// Redirect to selected page after order status completed/processing
add_action( 'woocommerce_thankyou', 'cwpai_woo_redirect_to_thank_you_page' );
function cwpai_woo_redirect_to_thank_you_page( $order_id ){
    $order = wc_get_order( $order_id );
    $order_items = $order->get_items();
    $selected_page = '';
    foreach( $order_items as $order_item ) {
        $product_id = $order_item->get_product_id();
        $product = wc_get_product( $product_id );
        $selected_page = $product->get_meta( '_thank_you_page' );
    }
    if ( !empty( $selected_page ) ) {
        wp_redirect( get_permalink( $selected_page ) );
        exit;
    }
}
?>